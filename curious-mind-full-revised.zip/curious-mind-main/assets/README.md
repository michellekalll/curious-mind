# Project Assets and Attribution

Store diagrams, illustrations, slide visuals, thumbnails, and storyboards used by this project here. The repository currently contains no separately inventoried image/media files, so no assets are listed as completed below. Add each real asset when it is created or selected.

## Asset register

| File path | Purpose | Creator/source | Licence/permission | Used in | Checked by |
|---|---|---|---|---|---|
| _No assets registered yet_ | — | — | — | — | — |

## Asset checklist

- [ ] Use clear, accessible visuals that support the learning objective.
- [ ] Record creator/source and licence or permission for every external asset.
- [ ] Add alternative text or a caption where useful.
- [ ] Check that no private or sensitive information is visible.
- [ ] Update the asset register; do not leave placeholder rows when assets exist.

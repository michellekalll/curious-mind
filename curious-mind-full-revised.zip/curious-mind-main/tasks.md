# Final Submission Task Tracker

**Important:** statuses below are a starting audit of the files currently present, not a claim that the team has completed the tasks. Assign an owner and due date based on the team's actual agreement.

| ID | Task | Suggested owner based on recorded roles | Status at audit | Evidence required to close |
|---|---|---|---|---|
| T01 | Compare repository against the instructor’s rubric and submission instructions | Coordinator + submission lead | **Needs rubric check** | Completed requirement-by-requirement checklist |
| T02 | Fact-check all six chapters and verify references | Quality lead + chapter authors | **Needs review** | Review notes and checked source list |
| T03 | Update the module outline to reflect actual chapter status | Coordinator | **Needs update** | Accurate status and remaining-work table |
| T04 | Complete peer-review responses and record real revisions | Assigned authors/reviewers | **Pending** | Responses, change evidence, and reviewer confirmation |
| T05 | Verify all practice-question answers and short-answer guidance | Quality lead | **Needs verification** | Checked key and explanations |
| T06 | Complete the study guide if a finished guide is required | Content lead | **Outline/draft present** | Final guide aligned with all six chapters |
| T07 | Review and finalize the draft slide deck | Visual design lead | **Draft PPTX created; needs review** | Check layout, source credits, rubric coverage, and required format |
| T08 | Record/edit the final video if required | Video lead | **Plan only** | Video file/link, captions, checked audio and facts |
| T09 | Deliver the mini-lecture and confirm whether a recording is required | Video lead + content authors | **Script present** | Final script and required recording/evidence |
| T10 | Register all visual assets and licences | Visual design lead | **No assets registered** | Accurate asset register |
| T11 | Confirm meeting notes reflect actual meetings | Coordinator | **Template needs completion** | Actual date, attendees, decisions, and actions |
| T12 | Check all links, spelling, naming, and repository navigation | Submission lead + quality lead | **Needs final QA** | Link check and final review sign-off |
| T13 | Confirm team names, student IDs, and responsibilities are accurate | Coordinator | **Needs confirmation** | Team confirmation |

## Final sign-off

- [ ] Rubric requirements checked one by one.
- [ ] All required deliverables are present in their required formats.
- [ ] No placeholder text remains unless explicitly allowed by the assignment.
- [ ] Review records describe work actually completed.
- [ ] References and media attributions have been verified.
- [ ] Team has opened the ZIP/repository from a fresh download and checked it.
- [ ] Final submission has been reviewed by the person responsible for submission.

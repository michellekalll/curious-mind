# Editing and Review Guide

1. Make focused edits and preserve the learning outcomes.
2. Support technical claims with reliable sources; verify that each source supports the claim.
3. Use beginner-friendly language and define new terms.
4. Keep chapter examples consistent with the study guide and practice bank.
5. When changing a filename, update all links in the repository.
6. Do not mark a review, meeting, task, or deliverable complete without evidence that it happened.
7. Before submission, compare every item with the instructor’s rubric.

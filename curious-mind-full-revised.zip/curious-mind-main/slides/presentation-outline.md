# Presentation Outline: Curious Mind — AI Overview

**Assigned to:** Lai Quoc Hung

## Slide 1: Title
- Curious Mind: AI Overview
- Team members and roles

## Slide 2: What Is AI?
- Definition of AI
- Everyday examples
- AI is not the same as human thinking

## Slide 3: AI, Machine Learning, and Deep Learning
- Explain the relationship between the terms
- Include a simple diagram

## Slide 4: Machine Learning
- Data, training, and prediction
- Supervised, unsupervised, and reinforcement learning

## Slide 5: Generative AI and LLMs
- Content generation
- Prompt examples
- Hallucinations and limitations

## Slide 6: Real-World Applications
- Education
- Healthcare
- Business
- Transportation
- Entertainment

## Slide 7: Responsible AI
- Fairness and bias
- Privacy
- Accuracy
- Transparency and accountability

## Slide 8: Practical AI Skills
- Write clear prompts
- Check important facts
- Follow academic-integrity rules

## Slide 9: Audience Activity
Ask the audience to evaluate a sample AI answer.
- Is it relevant?
- Are the claims accurate?
- What information is missing?

## Slide 10: Conclusion
- AI can be useful but has limitations.
- Verify important outputs.
- Use AI responsibly.

## Design Notes
Use short bullet points, readable text, consistent headings,
and visuals that help explain the concepts.

## Quality and delivery checklist

- [ ] Turn this outline into the required slide format (for example, PPTX or PDF) if the assignment asks for an actual presentation.
- [ ] Keep one key message per slide; use readable fonts and strong contrast.
- [ ] Add a labelled, accurate AI–ML–DL relationship diagram.
- [ ] Cite sources for statistics, claims, and external visuals on the relevant slide or in a references slide.
- [ ] Include speaker notes or a script if required.
- [ ] Test the audience activity and include a sample answer/debrief.
- [ ] Export and reopen the final file to check layout and links.

**Current status:** This file is an outline, not a finished slide deck. Update status only when the required presentation file exists and has been checked.

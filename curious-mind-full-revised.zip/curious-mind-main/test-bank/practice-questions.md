# Practice Question Bank: AI Overview

**Assigned to:** Samantha Salvatrice

## Multiple-Choice Questions

### 1. What is artificial intelligence?
A. Every program connected to the internet
B. A field focused on systems performing intelligent tasks
C. A computer that always thinks like a human
D. A device that only stores files

### 2. What does machine learning do?
A. Never uses data
B. Learns patterns from data or experience
C. Guarantees correct answers
D. Only follows fixed rules

### 3. Learning from emails labeled spam or not spam is:
A. Supervised learning
B. Unsupervised learning
C. Reinforcement learning
D. File compression

### 4. Predicting a numerical travel time is:
A. Classification
B. Regression
C. Source checking
D. Data labeling only

### 5. Generative AI is designed to:
A. Only store files
B. Create content such as text or images
C. Guarantee all information is true
D. Remove human responsibility

### 6. An AI hallucination is:
A. A verified source
B. False or unsupported information presented as true
C. A keyboard error
D. A training label

### 7. Responsible AI use for schoolwork means:
A. Copying every answer
B. Inventing sources
C. Following assignment rules and verifying claims
D. Sharing private information

### 8. AI bias can lead to:
A. Unfair or unequal outcomes
B. Guaranteed fairness
C. Faster typing only
D. More storage

### 9. Which action helps protect privacy?
A. Uploading private records to any chatbot
B. Sharing passwords
C. Avoiding sensitive information in unapproved tools
D. Posting confidential files publicly

### 10. Why should AI citations be checked?
A. All citations are fake
B. References may be incorrect or irrelevant
C. Sources never contain dates
D. Verification reduces accuracy

### 11. What is overfitting?
A. A model fits training data but performs poorly on new data
B. A model never trains
C. A model is always correct
D. A user opens a source

### 12. Which is the most specific prompt?
A. "Help."
B. "AI?"
C. "Explain supervised learning to a beginner in 120 words
   with two examples."
D. "Tell me something."

## Short-Answer Questions

13. Explain one difference between AI and rule-based automation.

14. Compare supervised and unsupervised learning.

15. Give one AI use in education and one possible risk.

16. Explain transparency and accountability.

17. List three ways to evaluate an AI-generated answer.

18. Describe one way to improve a prompt and one way to verify
    its response.

## Answer Key with Explanations

1. **B** — AI concerns systems performing tasks commonly associated with intelligent behavior; it does not mean every internet-connected program or a machine that thinks exactly like a person.
2. **B** — Machine learning identifies patterns from data or experience. It does not guarantee correct outputs.
3. **A** — The emails have labels (spam/not spam), so this is supervised learning.
4. **B** — Regression predicts a numerical value such as travel time. Classification predicts a category.
5. **B** — Generative AI creates content such as text, images, audio, or code; generated content is not automatically true.
6. **B** — A hallucination is an incorrect or unsupported output presented as if it were factual.
7. **C** — Responsible school use follows assignment rules and checks claims instead of copying blindly or inventing sources.
8. **A** — Biased data or design can contribute to unfair or unequal outcomes.
9. **C** — Avoiding sensitive information in unapproved tools reduces privacy risk.
10. **B** — AI-generated references can be inaccurate, nonexistent, or unrelated, so the source and its relevance must be checked.
11. **A** — Overfitting occurs when a model fits its training data too closely and generalizes poorly to new examples.
12. **C** — It specifies the topic, audience, approximate length, and number of examples, making the requested output clearer.

## Suggested Short-Answer Points

13. Rule-based automation follows specified rules; ML learns
    patterns from data. A product may combine both.
14. Supervised learning uses labeled examples; unsupervised
    learning looks for patterns without provided labels.
15. Example: practice questions. Risk: incorrect explanations
    or overdependence.
16. Transparency makes relevant system information understandable.
    Accountability means people or organizations remain
    responsible for outcomes.
17. Check accuracy, relevance, completeness, bias, dates,
    and source reliability.
18. Add task, context, audience, or format to a prompt.
    Verify claims with reliable independent sources.

## Assessment Quality Check

The answer key above is a proposed key based on the question wording. Before submission, a reviewer should independently solve each item, compare it with the final chapter text, and record the review date/name in the review notes. Short-answer points are examples of acceptable ideas, not an exhaustive marking rubric. If the assignment requires marks per question, add point values and criteria based on the teacher’s instructions.

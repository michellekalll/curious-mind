# Curious Mind: AI Overview

**A beginner-friendly learning module introducing artificial intelligence, machine learning, generative AI, applications, responsible use, and critical evaluation.**

## Project status

This repository contains six chapter drafts and supporting learning/assessment plans. The presence of a file does not mean it has been fully reviewed or that a planned presentation/video has been produced. Use [`tasks.md`](tasks.md) to track remaining work honestly and check all requirements against the instructor’s rubric before submission.

## Learning outcomes

By the end of this module, learners should be able to:
1. Define AI and explain how AI, machine learning, and deep learning relate.
2. Describe data, training, models, evaluation, and prediction.
3. Explain generative AI and large language models at an introductory level.
4. Identify AI applications and weigh their benefits and limitations.
5. Recognize concerns involving accuracy, bias, privacy, fairness, transparency, and human oversight.
6. Write useful prompts and verify AI-generated information.

## Contents

| Resource | Purpose |
|---|---|
| [Module outline](content/00-module-outline.md) | Scope, outcomes, topic plan, and status |
| [1. What is AI?](content/01-what-is-ai.md) | Definitions and core concepts |
| [2. Machine-learning basics](content/02-machine-learning-basics.md) | Data, model training, and learning types |
| [3. Generative AI and LLMs](content/03-generative-ai-and-llms.md) | Content generation, prompts, and limitations |
| [4. AI applications](content/04-ai-applications.md) | Industry examples and trade-offs |
| [5. Responsible AI](content/05-responsible-ai.md) | Fairness, privacy, reliability, and accountability |
| [6. Practical AI skills](content/06-practical-ai-skills.md) | Prompting and output evaluation |
| [Study guide](study-guide/study-guide.md) | Revision notes and review prompts |
| [Practice question bank](test-bank/practice-questions.md) | 12 multiple-choice and 6 short-answer questions |
| [PowerPoint presentation](slides/Curious-Mind-AI-Overview.pptx) | Draft 11-slide presentation for review |
| [Presentation outline](slides/presentation-outline.md) | Slide plan and delivery checklist |
| [Video plan](videos/video-plan.md) | Short introductory video production plan |
| [Video storyboard](videos/video-storyboard.md) | Shot-by-shot production guide; final video still needs to be produced |
| [Mini-lecture script](mini-lecture/mini-lecture-script.md) | Spoken introduction to AI |
| [Peer-review notes](review/review-notes.md) | Review checklist and peer feedback records |
| [Meeting notes](meeting-notes/meeting-notes.md) | Team coordination record template |
| [Asset inventory](assets/README.md) | Visual asset and attribution register |
| [Task tracker](tasks.md) | Outstanding work and verification checklist |

## Suggested learning sequence

Read Chapters 1–6 in order. Use the study guide to revise, then answer the practice questions without looking at the key. Use the presentation, video, and mini-lecture materials as production guides; do not describe a plan as a finished deliverable.

## Team and responsibilities

| Student ID | Name | Role recorded in the source repository |
|---|---|---|
| 1820262111 | Kristabelle Lian | Video Lead |
| 1820262301 | Le Tran Duc Trong | Repository and Submission Lead (CIO) |
| 1820262317 | Lai Quoc Hung | Visual Design Lead |
| 1820262334 | Samantha Salvatrice | Quality Lead |
| 1820262340 | Michelle Kalyani | Content Lead |
| 1820262344 | Jesselyn Kuolie | Coordinator (CEO) |

Please confirm that names, IDs, roles, and permission to publish them are correct before submitting.

## Sources and academic integrity

Chapter-level source suggestions are included in the content files. Verify each source and the claim it supports before submission. Attribute third-party text and media, follow course rules on AI assistance, and ensure the team understands and can explain the submitted work.

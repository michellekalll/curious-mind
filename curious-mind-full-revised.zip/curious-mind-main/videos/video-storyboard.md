# Video Storyboard — Curious Mind: AI Overview

**Target length:** approximately 4 minutes. **Audience:** beginner learners. **Status:** storyboard draft; no final video is included in this repository yet.

| Time | Narration / key message | Visual direction | On-screen text | QA notes |
|---|---|---|---|---|
| 0:00–0:20 | Introduce AI and ask where learners encounter it. | Simple icons representing navigation, recommendations, and spam filtering. | “Where do you encounter AI?” | Use original/licensed icons; add credits. |
| 0:20–0:55 | Define AI and clarify that AI does not think exactly like a human. | Show everyday examples, then a short definition. | “AI performs tasks associated with intelligent behavior.” | Avoid implying all AI works the same way. |
| 0:55–1:35 | Explain data, training, models, and predictions through spam detection. | Simple flow: labelled emails → training → model → new email classification. | “Data → Training → Model → Prediction” | Explain that performance depends on data and evaluation. |
| 1:35–2:15 | Explain generative AI and prompt specificity. | Compare a vague prompt with a prompt that specifies audience and format. | “Clear task + context + constraints” | Do not suggest prompt detail guarantees truth. |
| 2:15–2:55 | Give examples in education, healthcare, business, and transport. | Four labelled cards with one benefit and one risk each. | “Benefits and limitations” | Keep examples balanced and avoid unsupported statistics. |
| 2:55–3:40 | Cover accuracy, bias, privacy, and accountability. | Checklist graphic; no real personal information. | “Verify • Protect privacy • Consider fairness” | Reinforce human oversight and course rules. |
| 3:40–4:10 | Summarize practical habits. | Return to the opening icons and show three takeaways. | “Ask clearly. Verify. Use responsibly.” | Add captions, credits, and end card. |

## Production checklist

- [ ] Confirm script and storyboard with the team.
- [ ] Verify every factual claim against the chapters and sources.
- [ ] Create/record the video in the required format.
- [ ] Use original or properly licensed visuals and record attribution.
- [ ] Add accurate captions and check contrast/readability.
- [ ] Check audio levels, pacing, pronunciation, and export quality.
- [ ] Obtain the required review and link the final video from the README.
